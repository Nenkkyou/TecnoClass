/**
 * TecnoClass-PWA - Teste de Funcionalidade Offline
 * 
 * Este script implementa testes automatizados para verificar
 * o funcionamento offline do aplicativo.
 */

class OfflineTester {
  constructor() {
    this.testResults = {
      navigation: null,
      contentAccess: null,
      synchronization: null,
      quizzes: null,
      progressPersistence: null
    };
    
    this.testStatus = {
      running: false,
      currentTest: null,
      log: []
    };
  }
  
  /**
   * Inicia os testes de funcionalidade offline
   */
  async runTests() {
    if (this.testStatus.running) {
      console.warn('Testes já estão em execução');
      return;
    }
    
    this.testStatus.running = true;
    this.testStatus.log = [];
    this.logMessage('Iniciando testes de funcionalidade offline...');
    
    try {
      // Testa a navegação offline
      await this.testOfflineNavigation();
      
      // Testa o acesso a conteúdo salvo
      await this.testContentAccess();
      
      // Testa a sincronização ao reconectar
      await this.testSynchronization();
      
      // Testa o funcionamento dos quizzes offline
      await this.testOfflineQuizzes();
      
      // Testa a persistência de progresso
      await this.testProgressPersistence();
      
      // Gera o relatório final
      this.generateTestReport();
    } catch (error) {
      this.logMessage(`Erro durante os testes: ${error.message}`, 'error');
      console.error('Erro durante os testes:', error);
    } finally {
      this.testStatus.running = false;
    }
  }
  
  /**
   * Testa a navegação offline
   */
  async testOfflineNavigation() {
    this.testStatus.currentTest = 'navigation';
    this.logMessage('Testando navegação offline...');
    
    try {
      // Simula desconexão
      await this.simulateOffline(true);
      
      // Testa navegação para diferentes páginas
      const pages = [
        '/',
        '/cursos',
        '/quizzes',
        '/perfil'
      ];
      
      const results = [];
      
      for (const page of pages) {
        try {
          // Tenta navegar para a página
          const result = await this.navigateToPage(page);
          results.push({
            page,
            success: result.success,
            message: result.message
          });
          
          this.logMessage(`Navegação para ${page}: ${result.success ? 'Sucesso' : 'Falha'}`);
        } catch (e) {
          results.push({
            page,
            success: false,
            message: e.message
          });
          
          this.logMessage(`Erro ao navegar para ${page}: ${e.message}`, 'error');
        }
      }
      
      // Verifica os resultados
      const successCount = results.filter(r => r.success).length;
      const totalPages = pages.length;
      
      this.testResults.navigation = {
        success: successCount === totalPages,
        score: (successCount / totalPages) * 100,
        details: results
      };
      
      this.logMessage(`Teste de navegação offline concluído: ${successCount}/${totalPages} páginas acessíveis offline`);
      
      // Restaura conexão
      await this.simulateOffline(false);
    } catch (error) {
      this.testResults.navigation = {
        success: false,
        score: 0,
        details: [{
          page: 'geral',
          success: false,
          message: error.message
        }]
      };
      
      this.logMessage(`Erro no teste de navegação offline: ${error.message}`, 'error');
      
      // Restaura conexão
      await this.simulateOffline(false);
      throw error;
    }
  }
  
  /**
   * Testa o acesso a conteúdo salvo
   */
  async testContentAccess() {
    this.testStatus.currentTest = 'contentAccess';
    this.logMessage('Testando acesso a conteúdo salvo...');
    
    try {
      // Primeiro, salva algum conteúdo para acesso offline
      await this.simulateOffline(false);
      
      // Obtém lista de cursos
      const courses = await this.fetchCourses();
      if (!courses || courses.length === 0) {
        throw new Error('Nenhum curso disponível para teste');
      }
      
      // Salva o primeiro curso para acesso offline
      const testCourse = courses[0];
      await this.saveCourseOffline(testCourse.id);
      
      this.logMessage(`Curso "${testCourse.title}" salvo para acesso offline`);
      
      // Simula desconexão
      await this.simulateOffline(true);
      
      // Tenta acessar o curso salvo
      const accessResult = await this.accessCourseContent(testCourse.id);
      
      // Verifica se o conteúdo está acessível
      this.testResults.contentAccess = {
        success: accessResult.success,
        score: accessResult.success ? 100 : 0,
        details: accessResult
      };
      
      this.logMessage(`Teste de acesso a conteúdo salvo concluído: ${accessResult.success ? 'Sucesso' : 'Falha'}`);
      
      // Restaura conexão
      await this.simulateOffline(false);
    } catch (error) {
      this.testResults.contentAccess = {
        success: false,
        score: 0,
        details: {
          success: false,
          message: error.message
        }
      };
      
      this.logMessage(`Erro no teste de acesso a conteúdo salvo: ${error.message}`, 'error');
      
      // Restaura conexão
      await this.simulateOffline(false);
      throw error;
    }
  }
  
  /**
   * Testa a sincronização ao reconectar
   */
  async testSynchronization() {
    this.testStatus.currentTest = 'synchronization';
    this.logMessage('Testando sincronização ao reconectar...');
    
    try {
      // Simula desconexão
      await this.simulateOffline(true);
      
      // Realiza algumas ações offline
      const offlineActions = await this.performOfflineActions();
      
      this.logMessage(`Realizadas ${offlineActions.length} ações offline`);
      
      // Restaura conexão
      await this.simulateOffline(false);
      
      // Verifica se as ações foram sincronizadas
      const syncResults = await this.checkSynchronization(offlineActions);
      
      // Calcula a pontuação
      const successCount = syncResults.filter(r => r.success).length;
      const totalActions = syncResults.length;
      
      this.testResults.synchronization = {
        success: successCount === totalActions,
        score: totalActions > 0 ? (successCount / totalActions) * 100 : 0,
        details: syncResults
      };
      
      this.logMessage(`Teste de sincronização concluído: ${successCount}/${totalActions} ações sincronizadas`);
    } catch (error) {
      this.testResults.synchronization = {
        success: false,
        score: 0,
        details: [{
          action: 'geral',
          success: false,
          message: error.message
        }]
      };
      
      this.logMessage(`Erro no teste de sincronização: ${error.message}`, 'error');
      
      // Restaura conexão
      await this.simulateOffline(false);
      throw error;
    }
  }
  
  /**
   * Testa o funcionamento dos quizzes offline
   */
  async testOfflineQuizzes() {
    this.testStatus.currentTest = 'quizzes';
    this.logMessage('Testando funcionamento dos quizzes offline...');
    
    try {
      // Primeiro, salva um quiz para acesso offline
      await this.simulateOffline(false);
      
      // Obtém lista de quizzes
      const quizzes = await this.fetchQuizzes();
      if (!quizzes || quizzes.length === 0) {
        throw new Error('Nenhum quiz disponível para teste');
      }
      
      // Salva o primeiro quiz para acesso offline
      const testQuiz = quizzes[0];
      await this.saveQuizOffline(testQuiz.id);
      
      this.logMessage(`Quiz "${testQuiz.title}" salvo para acesso offline`);
      
      // Simula desconexão
      await this.simulateOffline(true);
      
      // Tenta completar o quiz offline
      const quizResult = await this.completeQuizOffline(testQuiz.id);
      
      // Verifica se o quiz funcionou corretamente
      this.testResults.quizzes = {
        success: quizResult.success,
        score: quizResult.success ? 100 : 0,
        details: quizResult
      };
      
      this.logMessage(`Teste de quizzes offline concluído: ${quizResult.success ? 'Sucesso' : 'Falha'}`);
      
      // Restaura conexão
      await this.simulateOffline(false);
    } catch (error) {
      this.testResults.quizzes = {
        success: false,
        score: 0,
        details: {
          success: false,
          message: error.message
        }
      };
      
      this.logMessage(`Erro no teste de quizzes offline: ${error.message}`, 'error');
      
      // Restaura conexão
      await this.simulateOffline(false);
      throw error;
    }
  }
  
  /**
   * Testa a persistência de progresso
   */
  async testProgressPersistence() {
    this.testStatus.currentTest = 'progressPersistence';
    this.logMessage('Testando persistência de progresso...');
    
    try {
      // Simula desconexão
      await this.simulateOffline(true);
      
      // Realiza progresso em um curso offline
      const progressResult = await this.makeOfflineProgress();
      
      this.logMessage(`Progresso realizado offline: ${progressResult.success ? 'Sucesso' : 'Falha'}`);
      
      // Restaura conexão
      await this.simulateOffline(false);
      
      // Verifica se o progresso foi persistido
      const persistenceResult = await this.checkProgressPersistence(progressResult.courseId, progressResult.lessonId);
      
      // Verifica os resultados
      this.testResults.progressPersistence = {
        success: persistenceResult.success,
        score: persistenceResult.success ? 100 : 0,
        details: persistenceResult
      };
      
      this.logMessage(`Teste de persistência de progresso concluído: ${persistenceResult.success ? 'Sucesso' : 'Falha'}`);
    } catch (error) {
      this.testResults.progressPersistence = {
        success: false,
        score: 0,
        details: {
          success: false,
          message: error.message
        }
      };
      
      this.logMessage(`Erro no teste de persistência de progresso: ${error.message}`, 'error');
      
      // Restaura conexão
      await this.simulateOffline(false);
      throw error;
    }
  }
  
  /**
   * Simula estado offline/online
   * @param {boolean} offline - Se deve simular estado offline
   */
  async simulateOffline(offline) {
    // Em um ambiente real, isso seria feito com Service Worker
    // ou com a API Network Information
    
    if (offline) {
      this.logMessage('Simulando desconexão...');
      
      // Armazena o estado original das funções de rede
      if (!window._originalFetch) {
        window._originalFetch = window.fetch;
      }
      
      // Sobrescreve fetch para simular offline
      window.fetch = async (url, options) => {
        // Permite requisições ao IndexedDB e cache
        if (url.includes('indexeddb') || url.includes('cache')) {
          return window._originalFetch(url, options);
        }
        
        // Simula erro de rede para outras requisições
        throw new Error('NetworkError: Failed to fetch');
      };
      
      // Dispara evento offline
      window.dispatchEvent(new Event('offline'));
    } else {
      this.logMessage('Simulando reconexão...');
      
      // Restaura a função fetch original
      if (window._originalFetch) {
        window.fetch = window._originalFetch;
      }
      
      // Dispara evento online
      window.dispatchEvent(new Event('online'));
    }
    
    // Aguarda um momento para que os handlers de eventos sejam executados
    return new Promise(resolve => setTimeout(resolve, 500));
  }
  
  /**
   * Navega para uma página
   * @param {string} page - URL da página
   * @returns {Promise<Object>} Resultado da navegação
   */
  async navigateToPage(page) {
    try {
      // Em um ambiente real, isso seria feito com o router
      // Aqui, simulamos a navegação verificando se a página está no cache
      
      // Verifica se a página está no cache
      const cache = await caches.open('tecnoclass-dynamic');
      const response = await cache.match(page);
      
      if (!response) {
        return {
          success: false,
          message: `Página ${page} não encontrada no cache`
        };
      }
      
      return {
        success: true,
        message: `Página ${page} acessível offline`
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
  
  /**
   * Busca a lista de cursos
   * @returns {Promise<Array>} Lista de cursos
   */
  async fetchCourses() {
    try {
      // Em um ambiente real, isso seria feito com uma API
      // Aqui, simulamos buscando do IndexedDB
      
      return await window.dbService.getAll('courses');
    } catch (error) {
      this.logMessage(`Erro ao buscar cursos: ${error.message}`, 'error');
      return [];
    }
  }
  
  /**
   * Salva um curso para acesso offline
   * @param {string} courseId - ID do curso
   */
  async saveCourseOffline(courseId) {
    try {
      // Em um ambiente real, isso seria feito com o sistema de download
      // Aqui, simulamos marcando o curso como disponível offline
      
      const course = await window.dbService.getById('courses', courseId);
      if (!course) {
        throw new Error(`Curso ${courseId} não encontrado`);
      }
      
      // Marca o curso como disponível offline
      await window.userDataService.addOfflineContent({
        id: courseId,
        type: 'course',
        title: course.title,
        size: JSON.stringify(course).length / 1024, // Tamanho aproximado em KB
        downloadDate: new Date().toISOString()
      });
      
      return true;
    } catch (error) {
      this.logMessage(`Erro ao salvar curso offline: ${error.message}`, 'error');
      return false;
    }
  }
  
  /**
   * Acessa o conteúdo de um curso
   * @param {string} courseId - ID do curso
   * @returns {Promise<Object>} Resultado do acesso
   */
  async accessCourseContent(courseId) {
    try {
      // Verifica se o curso está disponível offline
      const offlineContent = await window.userDataService.getOfflineContent();
      const isCourseOffline = offlineContent.some(item => item.id === courseId && item.type === 'course');
      
      if (!isCourseOffline) {
        return {
          success: false,
          message: `Curso ${courseId} não está disponível offline`
        };
      }
      
      // Tenta acessar o curso
      const course = await window.dbService.getById('courses', courseId);
      if (!course) {
        return {
          success: false,
          message: `Curso ${courseId} não encontrado no banco de dados local`
        };
      }
      
      // Verifica se consegue acessar as lições
      if (!course.modules || course.modules.length === 0) {
        return {
          success: false,
          message: `Curso ${courseId} não possui módulos`
        };
      }
      
      const firstModule = course.modules[0];
      if (!firstModule.lessons || firstModule.lessons.length === 0) {
        return {
          success: false,
          message: `Módulo ${firstModule.id} não possui lições`
        };
      }
      
      return {
        success: true,
        message: `Curso ${courseId} acessível offline`,
        courseTitle: course.title,
        moduleCount: course.modules.length,
        lessonCount: course.modules.reduce((count, module) => count + module.lessons.length, 0)
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
  
  /**
   * Realiza ações offline
   * @returns {Promise<Array>} Lista de ações realizadas
   */
  async performOfflineActions() {
    const actions = [];
    
    try {
      // 1. Adiciona uma anotação
      const noteResult = await this.addOfflineNote();
      if (noteResult.success) {
        actions.push({
          type: 'note',
          id: noteResult.noteId,
          success: true
        });
      }
      
      // 2. Marca uma lição como concluída
      const lessonResult = await this.completeOfflineLesson();
      if (lessonResult.success) {
        actions.push({
          type: 'lesson',
          courseId: lessonResult.courseId,
          lessonId: lessonResult.lessonId,
          success: true
        });
      }
      
      // 3. Adiciona um favorito
      const favoriteResult = await this.addOfflineFavorite();
      if (favoriteResult.success) {
        actions.push({
          type: 'favorite',
          id: favoriteResult.id,
          success: true
        });
      }
      
      return actions;
    } catch (error) {
      this.logMessage(`Erro ao realizar ações offline: ${error.message}`, 'error');
      return actions;
    }
  }
  
  /**
   * Adiciona uma anotação offline
   * @returns {Promise<Object>} Resultado da ação
   */
  async addOfflineNote() {
    try {
      // Cria uma anotação de teste
      const noteId = `note_${Date.now()}`;
      const note = {
        id: noteId,
        content: 'Esta é uma anotação de teste criada offline',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        syncStatus: 'pending'
      };
      
      // Salva a anotação
      await window.userDataService.saveNote(note);
      
      return {
        success: true,
        noteId
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
  
  /**
   * Marca uma lição como concluída offline
   * @returns {Promise<Object>} Resultado da ação
   */
  async completeOfflineLesson() {
    try {
      // Obtém um curso disponível
      const courses = await this.fetchCourses();
      if (!courses || courses.length === 0) {
        return {
          success: false,
          message: 'Nenhum curso disponível'
        };
      }
      
      const course = courses[0];
      if (!course.modules || course.modules.length === 0) {
        return {
          success: false,
          message: 'Curso não possui módulos'
        };
      }
      
      const module = course.modules[0];
      if (!module.lessons || module.lessons.length === 0) {
        return {
          success: false,
          message: 'Módulo não possui lições'
        };
      }
      
      const lesson = module.lessons[0];
      
      // Marca a lição como concluída
      await window.userDataService.markLessonComplete(course.id, lesson.id);
      
      return {
        success: true,
        courseId: course.id,
        lessonId: lesson.id
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
  
  /**
   * Adiciona um favorito offline
   * @returns {Promise<Object>} Resultado da ação
   */
  async addOfflineFavorite() {
    try {
      // Obtém um curso disponível
      const courses = await this.fetchCourses();
      if (!courses || courses.length === 0) {
        return {
          success: false,
          message: 'Nenhum curso disponível'
        };
      }
      
      const course = courses[0];
      
      // Adiciona o curso aos favoritos
      await window.userDataService.addFavorite({
        id: course.id,
        type: 'course',
        title: course.title,
        addedAt: new Date().toISOString(),
        syncStatus: 'pending'
      });
      
      return {
        success: true,
        id: course.id
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
  
  /**
   * Verifica se as ações offline foram sincronizadas
   * @param {Array} actions - Lista de ações realizadas
   * @returns {Promise<Array>} Resultados da sincronização
   */
  async checkSynchronization(actions) {
    const results = [];
    
    for (const action of actions) {
      try {
        let syncResult = false;
        
        switch (action.type) {
          case 'note':
            // Verifica se a anotação foi sincronizada
            const note = await window.userDataService.getNote(action.id);
            syncResult = note && note.syncStatus === 'synced';
            break;
            
          case 'lesson':
            // Verifica se a conclusão da lição foi sincronizada
            const progress = await window.userDataService.getLessonProgress(action.courseId, action.lessonId);
            syncResult = progress && progress.syncStatus === 'synced';
            break;
            
          case 'favorite':
            // Verifica se o favorito foi sincronizado
            const favorite = await window.userDataService.getFavorite(action.id);
            syncResult = favorite && favorite.syncStatus === 'synced';
            break;
        }
        
        results.push({
          action: action.type,
          id: action.id,
          success: syncResult,
          message: syncResult ? 'Sincronizado com sucesso' : 'Falha na sincronização'
        });
      } catch (error) {
        results.push({
          action: action.type,
          id: action.id,
          success: false,
          message: error.message
        });
      }
    }
    
    return results;
  }
  
  /**
   * Busca a lista de quizzes
   * @returns {Promise<Array>} Lista de quizzes
   */
  async fetchQuizzes() {
    try {
      return await window.dbService.getAll('quizzes');
    } catch (error) {
      this.logMessage(`Erro ao buscar quizzes: ${error.message}`, 'error');
      return [];
    }
  }
  
  /**
   * Salva um quiz para acesso offline
   * @param {string} quizId - ID do quiz
   */
  async saveQuizOffline(quizId) {
    try {
      const quiz = await window.dbService.getById('quizzes', quizId);
      if (!quiz) {
        throw new Error(`Quiz ${quizId} não encontrado`);
      }
      
      // Marca o quiz como disponível offline
      await window.userDataService.addOfflineContent({
        id: quizId,
        type: 'quiz',
        title: quiz.title,
        size: JSON.stringify(quiz).length / 1024, // Tamanho aproximado em KB
        downloadDate: new Date().toISOString()
      });
      
      return true;
    } catch (error) {
      this.logMessage(`Erro ao salvar quiz offline: ${error.message}`, 'error');
      return false;
    }
  }
  
  /**
   * Completa um quiz offline
   * @param {string} quizId - ID do quiz
   * @returns {Promise<Object>} Resultado da ação
   */
  async completeQuizOffline(quizId) {
    try {
      // Verifica se o quiz está disponível offline
      const offlineContent = await window.userDataService.getOfflineContent();
      const isQuizOffline = offlineContent.some(item => item.id === quizId && item.type === 'quiz');
      
      if (!isQuizOffline) {
        return {
          success: false,
          message: `Quiz ${quizId} não está disponível offline`
        };
      }
      
      // Obtém o quiz
      const quiz = await window.dbService.getById('quizzes', quizId);
      if (!quiz) {
        return {
          success: false,
          message: `Quiz ${quizId} não encontrado no banco de dados local`
        };
      }
      
      // Simula a conclusão do quiz
      const answers = quiz.questions.map((_, index) => Math.floor(Math.random() * 4)); // Respostas aleatórias
      
      // Calcula a pontuação
      let correctAnswers = 0;
      quiz.questions.forEach((question, index) => {
        if (answers[index] === question.correctOption) {
          correctAnswers++;
        }
      });
      
      const score = Math.round((correctAnswers / quiz.questions.length) * 100);
      
      // Salva o resultado do quiz
      await window.userDataService.saveQuizAttempt({
        quizId,
        quizTitle: quiz.title,
        date: new Date().toISOString(),
        score,
        timeSpent: '2m 30s',
        correctAnswers,
        totalQuestions: quiz.questions.length,
        syncStatus: 'pending'
      });
      
      return {
        success: true,
        message: `Quiz ${quizId} concluído offline`,
        quizTitle: quiz.title,
        score,
        correctAnswers,
        totalQuestions: quiz.questions.length
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
  
  /**
   * Realiza progresso em um curso offline
   * @returns {Promise<Object>} Resultado da ação
   */
  async makeOfflineProgress() {
    try {
      // Obtém um curso disponível
      const courses = await this.fetchCourses();
      if (!courses || courses.length === 0) {
        return {
          success: false,
          message: 'Nenhum curso disponível'
        };
      }
      
      const course = courses[0];
      if (!course.modules || course.modules.length === 0) {
        return {
          success: false,
          message: 'Curso não possui módulos'
        };
      }
      
      const module = course.modules[0];
      if (!module.lessons || module.lessons.length === 0) {
        return {
          success: false,
          message: 'Módulo não possui lições'
        };
      }
      
      const lesson = module.lessons[0];
      
      // Marca a lição como concluída
      await window.userDataService.markLessonComplete(course.id, lesson.id);
      
      // Atualiza o progresso do curso
      const progress = await window.userDataService.updateCourseProgress(course.id);
      
      return {
        success: true,
        courseId: course.id,
        lessonId: lesson.id,
        progress: progress.progress
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
  
  /**
   * Verifica se o progresso foi persistido
   * @param {string} courseId - ID do curso
   * @param {string} lessonId - ID da lição
   * @returns {Promise<Object>} Resultado da verificação
   */
  async checkProgressPersistence(courseId, lessonId) {
    try {
      // Verifica se a lição está marcada como concluída
      const lessonProgress = await window.userDataService.getLessonProgress(courseId, lessonId);
      if (!lessonProgress || !lessonProgress.completed) {
        return {
          success: false,
          message: `Lição ${lessonId} não está marcada como concluída`
        };
      }
      
      // Verifica se o progresso do curso foi atualizado
      const courseProgress = await window.userDataService.getCourseProgress(courseId);
      if (!courseProgress || courseProgress.progress === 0) {
        return {
          success: false,
          message: `Progresso do curso ${courseId} não foi atualizado`
        };
      }
      
      return {
        success: true,
        message: 'Progresso persistido com sucesso',
        courseId,
        lessonId,
        lessonCompleted: lessonProgress.completed,
        courseProgress: courseProgress.progress
      };
    } catch (error) {
      return {
        success: false,
        message: error.message
      };
    }
  }
  
  /**
   * Gera o relatório final de testes
   */
  generateTestReport() {
    // Calcula a pontuação geral
    const tests = Object.values(this.testResults).filter(test => test !== null);
    const totalScore = tests.reduce((sum, test) => sum + test.score, 0);
    const averageScore = tests.length > 0 ? totalScore / tests.length : 0;
    
    // Determina o status geral
    let overallStatus = 'Falha';
    if (averageScore >= 90) {
      overallStatus = 'Excelente';
    } else if (averageScore >= 70) {
      overallStatus = 'Bom';
    } else if (averageScore >= 50) {
      overallStatus = 'Regular';
    }
    
    // Cria o relatório
    const report = {
      timestamp: new Date().toISOString(),
      overallStatus,
      averageScore,
      tests: this.testResults,
      log: this.testStatus.log
    };
    
    // Exibe o relatório no console
    console.log('Relatório de Testes Offline:', report);
    
    // Salva o relatório no localStorage para referência
    localStorage.setItem('offlineTestReport', JSON.stringify(report));
    
    // Exibe uma mensagem com o resultado
    this.logMessage(`Testes concluídos! Pontuação média: ${averageScore.toFixed(2)}% - Status: ${overallStatus}`);
    
    return report;
  }
  
  /**
   * Registra uma mensagem no log
   * @param {string} message - Mensagem a ser registrada
   * @param {string} level - Nível da mensagem (info, warning, error)
   */
  logMessage(message, level = 'info') {
    const logEntry = {
      timestamp: new Date().toISOString(),
      message,
      level
    };
    
    this.testStatus.log.push(logEntry);
    
    // Exibe no console
    switch (level) {
      case 'warning':
        console.warn(message);
        break;
      case 'error':
        console.error(message);
        break;
      default:
        console.log(message);
    }
  }
}

// Exporta o testador offline
window.offlineTester = new OfflineTester();
