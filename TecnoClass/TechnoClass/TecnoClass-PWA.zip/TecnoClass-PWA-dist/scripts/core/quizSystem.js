/**
 * TecnoClass-PWA - Sistema de Quizzes Interativos
 * 
 * Este arquivo implementa o sistema de quizzes interativos para a aplicação,
 * permitindo aos usuários testarem seus conhecimentos.
 */

class QuizSystem {
  constructor() {
    this.dbService = window.dbService;
    this.userDataService = window.userDataService;
    this.currentQuiz = null;
    this.currentQuestion = 0;
    this.userAnswers = [];
    this.quizResults = null;
    
    // Inicializa quando o DOM estiver pronto
    document.addEventListener('DOMContentLoaded', () => {
      this.init();
    });
  }
  
  /**
   * Inicializa o sistema de quizzes
   */
  init() {
    this.setupEventListeners();
    this.setupRouteHandlers();
  }
  
  /**
   * Configura os listeners de eventos
   */
  setupEventListeners() {
    // Listener para cliques em cards de quizzes
    document.addEventListener('click', (e) => {
      const quizCard = e.target.closest('.quiz-card');
      if (quizCard) {
        const quizId = quizCard.getAttribute('data-quiz-id');
        if (quizId) {
          this.navigateToQuiz(quizId);
        }
      }
    });
  }
  
  /**
   * Configura os manipuladores de rotas
   */
  setupRouteHandlers() {
    // Define as rotas relacionadas a quizzes
    const quizRoutes = {
      '/quizzes': this.showQuizzesList.bind(this),
      '/quizzes/:quizId': this.showQuizDetails.bind(this),
      '/quizzes/:quizId/iniciar': this.startQuiz.bind(this),
      '/quizzes/:quizId/resultados': this.showQuizResults.bind(this)
    };
    
    // Registra as rotas no sistema de navegação
    if (window.router) {
      Object.entries(quizRoutes).forEach(([path, handler]) => {
        window.router.registerRoute(path, handler);
      });
    }
  }
  
  /**
   * Navega para a página de quizzes
   */
  navigateToQuizzes() {
    this.navigateTo('/quizzes');
  }
  
  /**
   * Navega para um quiz específico
   * @param {string} quizId - ID do quiz
   */
  navigateToQuiz(quizId) {
    this.navigateTo(`/quizzes/${quizId}`);
  }
  
  /**
   * Navega para iniciar um quiz
   * @param {string} quizId - ID do quiz
   */
  navigateToStartQuiz(quizId) {
    this.navigateTo(`/quizzes/${quizId}/iniciar`);
  }
  
  /**
   * Navega para os resultados de um quiz
   * @param {string} quizId - ID do quiz
   */
  navigateToQuizResults(quizId) {
    this.navigateTo(`/quizzes/${quizId}/resultados`);
  }
  
  /**
   * Função auxiliar para navegação
   * @param {string} path - Caminho da URL
   */
  navigateTo(path) {
    if (window.router) {
      window.router.navigateTo(path);
    } else {
      // Fallback simples
      window.history.pushState(null, '', path);
      this.handleRouteChange(path);
    }
  }
  
  /**
   * Manipula mudanças de rota
   * @param {string} path - Caminho da URL
   */
  handleRouteChange(path) {
    if (path === '/quizzes') {
      this.showQuizzesList();
    } else if (path.match(/^\/quizzes\/[^\/]+$/)) {
      const quizId = path.split('/').pop();
      this.showQuizDetails(quizId);
    } else if (path.match(/^\/quizzes\/[^\/]+\/iniciar$/)) {
      const quizId = path.split('/')[2];
      this.startQuiz(quizId);
    } else if (path.match(/^\/quizzes\/[^\/]+\/resultados$/)) {
      const quizId = path.split('/')[2];
      this.showQuizResults(quizId);
    }
  }
  
  /**
   * Exibe a lista de todos os quizzes
   */
  async showQuizzesList() {
    const appContent = document.getElementById('app-content');
    if (!appContent) return;
    
    try {
      // Obtém todos os quizzes do banco de dados
      const quizzes = await this.dbService.getAll('quizzes');
      
      // Agrupa quizzes por categoria
      const quizzesByCategory = this.groupQuizzesByCategory(quizzes);
      
      // Cria o HTML para a página de quizzes
      const html = `
        <section id="quizzes-page" class="screen">
          <div class="container">
            <div class="page-header">
              <h2>Quizzes Disponíveis</h2>
              <p>Teste seus conhecimentos com nossos quizzes interativos</p>
            </div>
            
            ${Object.entries(quizzesByCategory).map(([category, categoryQuizzes]) => `
              <div class="category-section">
                <h3 class="category-title">${this.getCategoryName(category)}</h3>
                <div class="quizzes-grid">
                  ${categoryQuizzes.map(quiz => this.createQuizCard(quiz)).join('')}
                </div>
              </div>
            `).join('')}
          </div>
        </section>
      `;
      
      // Atualiza o conteúdo
      appContent.innerHTML = html;
      
    } catch (error) {
      console.error('Erro ao carregar quizzes:', error);
      appContent.innerHTML = `
        <section class="screen">
          <div class="container">
            <div class="error-message">
              <h2>Erro ao carregar quizzes</h2>
              <p>Não foi possível carregar a lista de quizzes. Por favor, tente novamente mais tarde.</p>
              <button class="btn btn-primary" id="retry-quizzes">Tentar novamente</button>
            </div>
          </div>
        </section>
      `;
      
      document.getElementById('retry-quizzes')?.addEventListener('click', () => {
        this.showQuizzesList();
      });
    }
  }
  
  /**
   * Exibe os detalhes de um quiz específico
   * @param {string} quizId - ID do quiz
   */
  async showQuizDetails(quizId) {
    const appContent = document.getElementById('app-content');
    if (!appContent) return;
    
    try {
      // Obtém os dados do quiz
      const quiz = await this.dbService.getById('quizzes', quizId);
      if (!quiz) {
        throw new Error('Quiz não encontrado');
      }
      
      // Salva o quiz atual
      this.currentQuiz = quiz;
      
      // Obtém o histórico de tentativas do usuário para este quiz
      let attempts = [];
      try {
        attempts = await this.userDataService.getQuizAttempts(quizId);
      } catch (e) {
        console.warn('Não foi possível obter o histórico de tentativas:', e);
      }
      
      // Obtém a melhor pontuação
      const bestScore = attempts.length > 0 
        ? Math.max(...attempts.map(a => a.score)) 
        : 0;
      
      // Cria o HTML para a página de detalhes do quiz
      const html = `
        <section id="quiz-details" class="screen">
          <div class="container">
            <div class="quiz-header">
              <h2>${quiz.title}</h2>
              <div class="quiz-meta">
                <span class="quiz-category">${this.getCategoryName(quiz.category)}</span>
                <span class="quiz-difficulty">${this.getDifficultyLabel(quiz.difficulty)}</span>
                <span class="quiz-questions">${quiz.questions.length} questões</span>
              </div>
            </div>
            
            <div class="quiz-description">
              <p>${quiz.description}</p>
            </div>
            
            <div class="quiz-stats">
              <div class="stat-item">
                <span class="stat-label">Tentativas</span>
                <span class="stat-value">${attempts.length}</span>
              </div>
              <div class="stat-item">
                <span class="stat-label">Melhor Pontuação</span>
                <span class="stat-value">${bestScore}%</span>
              </div>
              <div class="stat-item">
                <span class="stat-label">Tempo Estimado</span>
                <span class="stat-value">${quiz.estimatedTime}</span>
              </div>
            </div>
            
            <div class="quiz-actions">
              <button class="btn btn-primary" id="start-quiz">Iniciar Quiz</button>
              ${attempts.length > 0 ? `
                <button class="btn btn-secondary" id="view-last-results">Ver Últimos Resultados</button>
              ` : ''}
            </div>
            
            ${attempts.length > 0 ? `
              <div class="quiz-history">
                <h3>Histórico de Tentativas</h3>
                <div class="history-list">
                  ${attempts.slice(0, 5).map(attempt => `
                    <div class="history-item">
                      <span class="history-date">${new Date(attempt.date).toLocaleDateString()}</span>
                      <span class="history-score">${attempt.score}%</span>
                      <span class="history-time">${attempt.timeSpent}</span>
                    </div>
                  `).join('')}
                </div>
              </div>
            ` : ''}
            
            <div class="navigation-buttons">
              <button class="btn btn-secondary" id="back-to-quizzes">Voltar para Quizzes</button>
            </div>
          </div>
        </section>
      `;
      
      // Atualiza o conteúdo
      appContent.innerHTML = html;
      
      // Adiciona event listeners
      document.getElementById('start-quiz')?.addEventListener('click', () => {
        this.navigateToStartQuiz(quizId);
      });
      
      document.getElementById('view-last-results')?.addEventListener('click', () => {
        if (attempts.length > 0) {
          // Carrega os resultados da última tentativa
          this.quizResults = attempts[0];
          this.navigateToQuizResults(quizId);
        }
      });
      
      document.getElementById('back-to-quizzes')?.addEventListener('click', () => {
        this.navigateToQuizzes();
      });
      
    } catch (error) {
      console.error(`Erro ao carregar quiz ${quizId}:`, error);
      appContent.innerHTML = `
        <section class="screen">
          <div class="container">
            <div class="error-message">
              <h2>Erro ao carregar quiz</h2>
              <p>Não foi possível carregar os detalhes deste quiz. Por favor, tente novamente mais tarde.</p>
              <button class="btn btn-primary" id="retry-quiz">Tentar novamente</button>
              <button class="btn btn-secondary" id="back-to-quizzes">Voltar para Quizzes</button>
            </div>
          </div>
        </section>
      `;
      
      document.getElementById('retry-quiz')?.addEventListener('click', () => {
        this.showQuizDetails(quizId);
      });
      
      document.getElementById('back-to-quizzes')?.addEventListener('click', () => {
        this.navigateToQuizzes();
      });
    }
  }
  
  /**
   * Inicia um quiz
   * @param {string} quizId - ID do quiz
   */
  async startQuiz(quizId) {
    const appContent = document.getElementById('app-content');
    if (!appContent) return;
    
    try {
      // Obtém os dados do quiz se ainda não estiverem carregados
      if (!this.currentQuiz || this.currentQuiz.id !== quizId) {
        this.currentQuiz = await this.dbService.getById('quizzes', quizId);
        if (!this.currentQuiz) {
          throw new Error('Quiz não encontrado');
        }
      }
      
      // Reinicia o estado do quiz
      this.currentQuestion = 0;
      this.userAnswers = Array(this.currentQuiz.questions.length).fill(null);
      this.quizStartTime = Date.now();
      
      // Renderiza a primeira questão
      this.renderCurrentQuestion(appContent);
      
    } catch (error) {
      console.error(`Erro ao iniciar quiz ${quizId}:`, error);
      appContent.innerHTML = `
        <section class="screen">
          <div class="container">
            <div class="error-message">
              <h2>Erro ao iniciar quiz</h2>
              <p>Não foi possível iniciar este quiz. Por favor, tente novamente mais tarde.</p>
              <button class="btn btn-primary" id="retry-start">Tentar novamente</button>
              <button class="btn btn-secondary" id="back-to-quiz">Voltar para Detalhes</button>
            </div>
          </div>
        </section>
      `;
      
      document.getElementById('retry-start')?.addEventListener('click', () => {
        this.startQuiz(quizId);
      });
      
      document.getElementById('back-to-quiz')?.addEventListener('click', () => {
        this.navigateToQuiz(quizId);
      });
    }
  }
  
  /**
   * Renderiza a questão atual
   * @param {HTMLElement} container - Elemento container
   */
  renderCurrentQuestion(container) {
    if (!this.currentQuiz || !container) return;
    
    const question = this.currentQuiz.questions[this.currentQuestion];
    if (!question) return;
    
    // Cria o HTML para a questão
    const html = `
      <section id="quiz-question" class="screen">
        <div class="container">
          <div class="quiz-progress">
            <div class="progress-text">Questão ${this.currentQuestion + 1} de ${this.currentQuiz.questions.length}</div>
            <div class="progress-bar">
              <div class="progress-indicator" style="width: ${(this.currentQuestion + 1) / this.currentQuiz.questions.length * 100}%"></div>
            </div>
          </div>
          
          <div class="question-container">
            <h2 class="question-text">${question.text}</h2>
            
            <div class="options-list">
              ${question.options.map((option, index) => `
                <div class="option-item ${this.userAnswers[this.currentQuestion] === index ? 'selected' : ''}" data-option-index="${index}">
                  <span class="option-marker">${String.fromCharCode(65 + index)}</span>
                  <span class="option-text">${option}</span>
                </div>
              `).join('')}
            </div>
          </div>
          
          <div class="quiz-navigation">
            ${this.currentQuestion > 0 ? `
              <button class="btn btn-secondary" id="prev-question">Anterior</button>
            ` : `
              <div></div>
            `}
            
            <button class="btn btn-primary" id="next-question" ${this.userAnswers[this.currentQuestion] === null ? 'disabled' : ''}>
              ${this.currentQuestion < this.currentQuiz.questions.length - 1 ? 'Próxima' : 'Finalizar Quiz'}
            </button>
          </div>
        </div>
      </section>
    `;
    
    // Atualiza o conteúdo
    container.innerHTML = html;
    
    // Adiciona event listeners
    document.querySelectorAll('.option-item').forEach(option => {
      option.addEventListener('click', (e) => {
        const optionIndex = parseInt(option.getAttribute('data-option-index'), 10);
        
        // Remove a seleção anterior
        document.querySelectorAll('.option-item').forEach(opt => {
          opt.classList.remove('selected');
        });
        
        // Seleciona a opção clicada
        option.classList.add('selected');
        
        // Salva a resposta do usuário
        this.userAnswers[this.currentQuestion] = optionIndex;
        
        // Habilita o botão de próxima
        const nextButton = document.getElementById('next-question');
        if (nextButton) {
          nextButton.removeAttribute('disabled');
        }
      });
    });
    
    document.getElementById('prev-question')?.addEventListener('click', () => {
      if (this.currentQuestion > 0) {
        this.currentQuestion--;
        this.renderCurrentQuestion(container);
      }
    });
    
    document.getElementById('next-question')?.addEventListener('click', () => {
      if (this.currentQuestion < this.currentQuiz.questions.length - 1) {
        // Avança para a próxima questão
        this.currentQuestion++;
        this.renderCurrentQuestion(container);
      } else {
        // Finaliza o quiz
        this.finishQuiz();
      }
    });
  }
  
  /**
   * Finaliza o quiz e calcula os resultados
   */
  async finishQuiz() {
    if (!this.currentQuiz) return;
    
    // Calcula o tempo gasto
    const quizEndTime = Date.now();
    const timeSpentMs = quizEndTime - this.quizStartTime;
    const timeSpentMinutes = Math.floor(timeSpentMs / 60000);
    const timeSpentSeconds = Math.floor((timeSpentMs % 60000) / 1000);
    const timeSpent = `${timeSpentMinutes}m ${timeSpentSeconds}s`;
    
    // Calcula a pontuação
    let correctAnswers = 0;
    const detailedResults = this.currentQuiz.questions.map((question, index) => {
      const isCorrect = this.userAnswers[index] === question.correctOption;
      if (isCorrect) correctAnswers++;
      
      return {
        questionText: question.text,
        userAnswer: this.userAnswers[index],
        correctAnswer: question.correctOption,
        isCorrect,
        explanation: question.explanation || ''
      };
    });
    
    const score = Math.round((correctAnswers / this.currentQuiz.questions.length) * 100);
    
    // Cria o objeto de resultados
    this.quizResults = {
      quizId: this.currentQuiz.id,
      quizTitle: this.currentQuiz.title,
      date: new Date().toISOString(),
      score,
      timeSpent,
      correctAnswers,
      totalQuestions: this.currentQuiz.questions.length,
      detailedResults
    };
    
    // Salva os resultados no banco de dados
    try {
      await this.userDataService.saveQuizAttempt(this.quizResults);
    } catch (e) {
      console.warn('Não foi possível salvar os resultados do quiz:', e);
    }
    
    // Navega para a página de resultados
    this.navigateToQuizResults(this.currentQuiz.id);
  }
  
  /**
   * Exibe os resultados de um quiz
   * @param {string} quizId - ID do quiz
   */
  async showQuizResults(quizId) {
    const appContent = document.getElementById('app-content');
    if (!appContent) return;
    
    try {
      // Verifica se temos os resultados
      if (!this.quizResults) {
        // Tenta carregar a última tentativa
        const attempts = await this.userDataService.getQuizAttempts(quizId);
        if (attempts.length > 0) {
          this.quizResults = attempts[0];
        } else {
          throw new Error('Nenhum resultado disponível');
        }
      }
      
      // Obtém os dados do quiz se ainda não estiverem carregados
      if (!this.currentQuiz || this.currentQuiz.id !== quizId) {
        this.currentQuiz = await this.dbService.getById('quizzes', quizId);
        if (!this.currentQuiz) {
          throw new Error('Quiz não encontrado');
        }
      }
      
      // Determina a mensagem de feedback com base na pontuação
      let feedbackMessage = '';
      let feedbackClass = '';
      
      if (this.quizResults.score >= 90) {
        feedbackMessage = 'Excelente! Você domina este assunto.';
        feedbackClass = 'excellent';
      } else if (this.quizResults.score >= 70) {
        feedbackMessage = 'Muito bom! Você tem um bom conhecimento.';
        feedbackClass = 'good';
      } else if (this.quizResults.score >= 50) {
        feedbackMessage = 'Bom trabalho! Mas há espaço para melhorias.';
        feedbackClass = 'average';
      } else {
        feedbackMessage = 'Continue estudando! Este tópico precisa de mais atenção.';
        feedbackClass = 'needs-improvement';
      }
      
      // Cria o HTML para a página de resultados
      const html = `
        <section id="quiz-results" class="screen">
          <div class="container">
            <div class="results-header">
              <h2>Resultados do Quiz</h2>
              <h3>${this.currentQuiz.title}</h3>
            </div>
            
            <div class="results-summary">
              <div class="score-container ${feedbackClass}">
                <div class="score-circle">
                  <span class="score-value">${this.quizResults.score}%</span>
                </div>
                <p class="score-feedback">${feedbackMessage}</p>
              </div>
              
              <div class="results-stats">
                <div class="stat-item">
                  <span class="stat-label">Respostas Corretas</span>
                  <span class="stat-value">${this.quizResults.correctAnswers} de ${this.quizResults.totalQuestions}</span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">Tempo Gasto</span>
                  <span class="stat-value">${this.quizResults.timeSpent}</span>
                </div>
                <div class="stat-item">
                  <span class="stat-label">Data</span>
                  <span class="stat-value">${new Date(this.quizResults.date).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
            
            <div class="detailed-results">
              <h3>Revisão Detalhada</h3>
              
              ${this.quizResults.detailedResults.map((result, index) => `
                <div class="question-result ${result.isCorrect ? 'correct' : 'incorrect'}">
                  <div class="question-header">
                    <span class="question-number">Questão ${index + 1}</span>
                    <span class="question-status">${result.isCorrect ? 'Correta' : 'Incorreta'}</span>
                  </div>
                  <p class="question-text">${result.questionText}</p>
                  
                  <div class="answer-details">
                    <div class="user-answer">
                      <span class="answer-label">Sua resposta:</span>
                      <span class="answer-value ${result.isCorrect ? 'correct' : 'incorrect'}">
                        ${String.fromCharCode(65 + result.userAnswer)} - ${this.currentQuiz.questions[index].options[result.userAnswer]}
                      </span>
                    </div>
                    
                    ${!result.isCorrect ? `
                      <div class="correct-answer">
                        <span class="answer-label">Resposta correta:</span>
                        <span class="answer-value correct">
                          ${String.fromCharCode(65 + result.correctAnswer)} - ${this.currentQuiz.questions[index].options[result.correctAnswer]}
                        </span>
                      </div>
                    ` : ''}
                  </div>
                  
                  ${result.explanation ? `
                    <div class="explanation">
                      <span class="explanation-label">Explicação:</span>
                      <p class="explanation-text">${result.explanation}</p>
                    </div>
                  ` : ''}
                </div>
              `).join('')}
            </div>
            
            <div class="results-actions">
              <button class="btn btn-primary" id="retry-quiz">Tentar Novamente</button>
              <button class="btn btn-secondary" id="back-to-quiz">Voltar para Detalhes</button>
            </div>
          </div>
        </section>
      `;
      
      // Atualiza o conteúdo
      appContent.innerHTML = html;
      
      // Adiciona event listeners
      document.getElementById('retry-quiz')?.addEventListener('click', () => {
        this.startQuiz(quizId);
      });
      
      document.getElementById('back-to-quiz')?.addEventListener('click', () => {
        this.navigateToQuiz(quizId);
      });
      
    } catch (error) {
      console.error(`Erro ao mostrar resultados do quiz ${quizId}:`, error);
      appContent.innerHTML = `
        <section class="screen">
          <div class="container">
            <div class="error-message">
              <h2>Erro ao carregar resultados</h2>
              <p>Não foi possível carregar os resultados deste quiz. Por favor, tente novamente mais tarde.</p>
              <button class="btn btn-secondary" id="back-to-quiz">Voltar para Detalhes</button>
            </div>
          </div>
        </section>
      `;
      
      document.getElementById('back-to-quiz')?.addEventListener('click', () => {
        this.navigateToQuiz(quizId);
      });
    }
  }
  
  /**
   * Agrupa quizzes por categoria
   * @param {Array} quizzes - Lista de quizzes
   * @returns {Object} Quizzes agrupados por categoria
   */
  groupQuizzesByCategory(quizzes) {
    const grouped = {};
    
    quizzes.forEach(quiz => {
      if (!grouped[quiz.category]) {
        grouped[quiz.category] = [];
      }
      
      grouped[quiz.category].push(quiz);
    });
    
    return grouped;
  }
  
  /**
   * Obtém o nome de uma categoria a partir do seu ID
   * @param {string} categoryId - ID da categoria
   * @returns {string} Nome da categoria
   */
  getCategoryName(categoryId) {
    const categories = {
      'programacao': 'Programação',
      'cyber': 'Cybersegurança',
      'ia': 'Inteligência Artificial',
      'po': 'Product Owner'
    };
    
    return categories[categoryId] || categoryId;
  }
  
  /**
   * Obtém o rótulo de dificuldade
   * @param {string} difficulty - Nível de dificuldade
   * @returns {string} Rótulo de dificuldade
   */
  getDifficultyLabel(difficulty) {
    const labels = {
      'easy': 'Fácil',
      'medium': 'Médio',
      'hard': 'Difícil',
      'expert': 'Especialista'
    };
    
    return labels[difficulty] || difficulty;
  }
  
  /**
   * Cria o HTML para um card de quiz
   * @param {Object} quiz - Dados do quiz
   * @returns {string} HTML do card
   */
  createQuizCard(quiz) {
    return `
      <div class="quiz-card" data-quiz-id="${quiz.id}">
        <div class="quiz-card-header">
          <span class="quiz-category">${this.getCategoryName(quiz.category)}</span>
          <span class="quiz-difficulty">${this.getDifficultyLabel(quiz.difficulty)}</span>
        </div>
        <h3 class="quiz-title">${quiz.title}</h3>
        <p class="quiz-description">${this.truncateText(quiz.description, 80)}</p>
        <div class="quiz-meta">
          <span class="quiz-questions">${quiz.questions.length} questões</span>
          <span class="quiz-time">${quiz.estimatedTime}</span>
        </div>
      </div>
    `;
  }
  
  /**
   * Trunca um texto para um tamanho máximo
   * @param {string} text - Texto a ser truncado
   * @param {number} maxLength - Tamanho máximo
   * @returns {string} Texto truncado
   */
  truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }
}

// Exporta o sistema de quizzes
window.quizSystem = new QuizSystem();
